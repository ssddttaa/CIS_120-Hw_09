//Class that stores the name and score associated with that name
public class Score {
	String name;
	int score;
	Score(String name, int score){
		this.name = name;
		this.score = score;
	}
}
